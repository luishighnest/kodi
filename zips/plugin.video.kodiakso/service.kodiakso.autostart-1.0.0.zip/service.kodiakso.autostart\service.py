# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()
TARGET = 'plugin.video.kodiakso'


def autostart():
    if not ADDON.getSettingBool('enabled'):
        xbmc.log('PZ8 Autostart: disabilitato nelle impostazioni', xbmc.LOGINFO)
        return

    if not xbmc.getCondVisibility('System.HasAddon(%s)' % TARGET):
        xbmc.log('PZ8 Autostart: %s non installato' % TARGET, xbmc.LOGWARNING)
        return

    delay = ADDON.getSettingInt('delay') or 0
    if delay > 0:
        xbmc.sleep(delay * 1000)

    xbmc.log('PZ8 Autostart: apro %s' % TARGET, xbmc.LOGINFO)
    xbmc.executebuiltin('RunAddon(%s)' % TARGET)


if __name__ == '__main__':
    autostart()
